-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 10-02-2020 a las 08:18:37
-- Versión del servidor: 10.3.16-MariaDB
-- Versión de PHP: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `id12464293_cinema`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cartelera`
--

CREATE TABLE `cartelera` (
  `id_pelicula` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `actores` varchar(350) NOT NULL,
  `director` varchar(100) NOT NULL,
  `pais` varchar(50) NOT NULL,
  `año` int(10) NOT NULL,
  `genero` varchar(150) NOT NULL,
  `link_imagen` varchar(180) NOT NULL,
  `taquillero` int(150) NOT NULL,
  `estreno` int(11) NOT NULL,
  `link_video` varchar(150) NOT NULL,
  `descripcion` varchar(535) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `cartelera`
--

INSERT INTO `cartelera` (`id_pelicula`, `nombre`, `actores`, `director`, `pais`, `año`, `genero`, `link_imagen`, `taquillero`, `estreno`, `link_video`, `descripcion`) VALUES
(2, 'Jumanji', 'Dwayne Johnson,Kevin Hart,Jack Black,Karen Gillan,Danny DeVito', 'Jake Kasdan', 'Estados Unidos', 2017, 'Acción', 'img_peliculas/p2.jpg', 10, 1, 'https://www.youtube.com/embed/Di9miQw0FP0', 'Cuatro adolescentes encuentran un viejo videojuego que los absorbe y los transporta a una selva peligrosa, donde se convierten en personajes adultos y tienen que ir superando pruebas terribles para terminar el juego y regresar al mundo real.'),
(3, 'Thor', 'Chris Hermsworth,Tom Hiddleston,Natalie Portman', 'Kenneth Branagh', 'Estados Unidos', 2011, 'Fantasia', 'img_peliculas/p3.jpg', 30, 1, 'https://www.youtube.com/embed/JOddp-nlNvQ', 'Tras desatar una antigua guerra, el codicioso guerrero Thor es desterrado a la Tierra por su padre para que viva entre los hombres y descubra así el verdadero sentido de la humildad. Allí, sin sus poderes, Thor deberá enfrentarse a las fuerzas más oscuras que su mayor enemigo le enviará desde Asgard.'),
(4, 'No culpes al karma', 'Verónica Echegui,Álex García Fernández ,David Verdaguer', 'María Ripoll', 'Estados Unidos', 2018, 'comedia', 'img_peliculas/p4.jpg', 39, 1, 'https://www.youtube.com/embed/2ufHXTryOKY', 'No culpes al karma de lo que te pasa por gilipollas es una novela de la escritora Laura Norton publicada el 29 de abril de 2014. Forma parte de una saga, cuya segunda parte se titula Ante todo, mucho karma.'),
(5, 'Secretos de estado', 'aissa Farmiga,Demián Bichir,Pepe del toro,maestro rochi', 'rigoberto de ungria', 'Reino unido', 2019, 'drama', 'img_peliculas/p5.jpg', 40, 1, 'https://www.youtube.com/embed/-MHG5vYE_ps', 'Un hombre de negocios y su familia se ven atrapados en medio de un violento golpe de estado en un país del sudeste asiático. Mientras los rebeldes atacan, Jack y su familia tienen que buscar la forma de sobrevivir al infierno.'),
(6, 'Sin Tiempo Para Morir', 'Daniel Craig,Rami Malek,Lea Seydoux', 'Cary Fukunaga', 'Alemania', 2020, 'Misterio/Suspenso', 'img_peliculas/estre1.jpg', 0, 0, 'https://www.youtube.com/embed/gnsQuFU25zM', 'EL legendario espía James Bond ha dejado el servicio activo. Su paz dura poco ya que su viejo amigo Felix Leiter de la CIA aparece pidiendo ayuda, lo que lleva a Bond al rastro de un misterioso villano armado con nueva tecnología peligrosa.'),
(7, 'Morbus', 'Jared Leto,Adria Arjona,Jared Harris,Tyrese Gibson', 'Daniel Espinosa', 'Rusia', 2020, 'Drama/Suspenso', 'img_peliculas/estre2.jpg', 0, 0, 'https://www.youtube.com/embed/30U5_Zp8VCw', 'Ambientada en el universo de Spider Man, se centra en uno de sus villanos más icónicos, Morbius, un doctor que tras sufrir una enfermedad en la sangre y fallar al intentar curarse, se convirtió en un vampiro.'),
(8, 'Venom 2', 'Tom Hardy,Woody Harrelson,Michelle Wiliams,Naomie Harris', 'Andy Serkis', 'Estados Unidos', 2020, 'Ficcion/Drama', 'img_peliculas/estre3.jpg', 0, 0, 'https://www.youtube.com/embed/8cG1aVT-M-A', 'Venom 2 es una próxima película estadounidense de superhéroes, basada en el personaje de Marvel, llamado Venom, dirigida por Andy Serkis producida por Columbia Pictures en asociación con Marvel.'),
(9, 'BOB ESPONJA', 'Keanu Reeves,Tom Kenny,Awkwafina', 'Tim Hill', 'Estados Unidos', 2021, 'Aventura/Comedia', 'img_peliculas/estre4.jpg', 0, 0, 'https://www.youtube.com/embed/HfiH_526qhY', 'Bob Esponja y Patricio deciden viajar a la ciudad perdida de Atlantic City para encontrar a Gary, el caracol.'),
(10, 'Mulan', 'Donnie Yen,Jet Li,Gong Li,Jason Scott', 'Niki Caro', 'Japon', 2020, 'Drama', 'img_peliculas/estre5.jpg', 0, 0, 'https://www.youtube.com/embed/R-eFm--k21c', 'El emperador chino emite un decreto que exige que cada hogar debe reclutar a un varón para luchar con el ejército imperial en la guerra contra los Hunos.'),
(24, '', '', '', '', 0, '', '', 0, 0, '', ''),
(25, 'Batman', 'Christian Charles Philip Bale', 'Nolan', 'EUA', 2008, 'Accion', 'img_peliculas/batman.jpeg', 0, 1, 'https://www.youtube.com/embed/EXeTwQWrcwY', 'Después de la muerte de sus padres, el joven heredero Bruce Wayne se convierte en un vengador enmascarado que lucha contra las fuerzas del mal en Ciudad Gótica.'),
(26, '', '', '', '', 0, '', '', 0, 0, '', ''),
(27, 'AVENGERS3', '', '', '', 0, '', '', 0, 0, '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `funciones`
--

CREATE TABLE `funciones` (
  `id_funcion` int(11) NOT NULL,
  `id_pelicula` int(11) NOT NULL,
  `sala` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `horario` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `funciones`
--

INSERT INTO `funciones` (`id_funcion`, `id_pelicula`, `sala`, `horario`) VALUES
(1, 2, '111110000000001100001111100001100001111100001100001111100001100001111100001100001111100001000011', '10:00'),
(7, 24, '111110000000001100001111100001100001111100001100001111100001100001111100001100001111100001000011', '00:00'),
(8, 25, '111110000000001100001111100001100001111100001100001111100001100001111100001100001111100001000011', '12:30'),
(9, 26, '0', '00:00'),
(10, 27, '0', '00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `promociones`
--

CREATE TABLE `promociones` (
  `id` int(11) NOT NULL,
  `img_promo` varchar(500) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `promociones`
--

INSERT INTO `promociones` (`id`, `img_promo`) VALUES
(1, 'img_promo/promo1.jpg'),
(2, 'img_promo/promo2.jpg'),
(4, 'img_promo/promo3.jpg'),
(5, 'img_promo/promo5.jpg'),
(6, 'img_promo/promo6.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservaciones`
--

CREATE TABLE `reservaciones` (
  `id_pelicula` int(11) NOT NULL,
  `codigo_reservaciones` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cartelera`
--
ALTER TABLE `cartelera`
  ADD PRIMARY KEY (`id_pelicula`);

--
-- Indices de la tabla `funciones`
--
ALTER TABLE `funciones`
  ADD PRIMARY KEY (`id_funcion`),
  ADD KEY `id_pelicula` (`id_pelicula`);

--
-- Indices de la tabla `promociones`
--
ALTER TABLE `promociones`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `reservaciones`
--
ALTER TABLE `reservaciones`
  ADD KEY `id_pelicula` (`id_pelicula`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cartelera`
--
ALTER TABLE `cartelera`
  MODIFY `id_pelicula` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT de la tabla `funciones`
--
ALTER TABLE `funciones`
  MODIFY `id_funcion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `promociones`
--
ALTER TABLE `promociones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `funciones`
--
ALTER TABLE `funciones`
  ADD CONSTRAINT `funciones_ibfk_1` FOREIGN KEY (`id_pelicula`) REFERENCES `cartelera` (`id_pelicula`),
  ADD CONSTRAINT `funciones_ibfk_2` FOREIGN KEY (`id_pelicula`) REFERENCES `cartelera` (`id_pelicula`);

--
-- Filtros para la tabla `reservaciones`
--
ALTER TABLE `reservaciones`
  ADD CONSTRAINT `reservaciones_ibfk_1` FOREIGN KEY (`id_pelicula`) REFERENCES `cartelera` (`id_pelicula`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
