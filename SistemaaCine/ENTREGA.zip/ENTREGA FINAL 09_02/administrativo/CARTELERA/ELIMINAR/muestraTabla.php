

<!--Fernando Sanchez Morales
	Realizaremos las respectivas consultas que el usuario quiera efectuar por medio de el id de la pelicula-->

<?php #inicializacion del codigo php
  require_once "../../../biblioteca.php";//llamamos a la biblioteca que contiene la conexion
$conexion =conectaDB();//asignamos a una variable la conexion a la base de datos

?>

<!DOCTYPE html>
<html>
<head>
	<title>Mostrar datos</title>
</head>

<body style="background-color:#FFFFFF;">
<div style="display: flex;  justify-content: flex-start; " >
	<div style="display: flex;" >
		<img src="../../../imagenes/logo.png" height="180px" width="180px">
	</div>
	<div style="display: flex;width:580px;height:180px;background-color:#FFFFFF  "> </div>
	<div style="display: flex; align-items: center; ">
		<strong><h1 >Mostrar datos</h1></strong>
	</div>
</div>

<div style="margin-top: 50px">
	<table border="1" >
			<td bgcolor="#0dcfac"> id pelicula</td>
			<td  bgcolor="#0dcfac">nombre</td>
			<td  bgcolor="#94a993">descripcion</td>
			<td bgcolor="#94a993">linkvideo</td>
			<td bgcolor="#94a993">estreno</td>
			<td bgcolor="#94a993">linkimagen</td>
			<td bgcolor="#94a993">taquillero</td>
			<td bgcolor="#94a993">actores</td>
			<td bgcolor="#94a993">director</td>
			<td bgcolor="#94a993">pais</td>
			<td bgcolor="#94a993">año</td>
			<td bgcolor="#94a993">genero</td>


	<?php
	
		$numero = $_POST['id_pelicula'];

		



	$sql="DELETE FROM funciones WHERE id_pelicula=$numero";

		$ejecutar=mysqli_query($conexion,$sql);       	//verificamos la ejecucion
		if(!$ejecutar){
			echo"Hubo Algun Error";
		}else{
			echo"Datos 	eliminado Correctamente";
		}

		
	$sql="DELETE FROM cartelera WHERE id_pelicula=$numero";

		$ejecutar=mysqli_query($conexion,$sql);       	//verificamos la ejecucion
		if(!$ejecutar){
			echo"Hubo Algun Error";
		}else{
			echo"Datos 	eliminado Correctamente";
		}
			
	
						
								
?>


		<?php 
	
		$sql="SELECT * from  cartelera";
		$result=mysqli_query($conexion,$sql);

		while($mostrar=mysqli_fetch_array($result) ){
		?>
		 	
		<tr>
			<td><?php {echo $mostrar['id_pelicula']; }?></td>
			<td><?php {echo $mostrar['nombre']; }?></td>
			<td><?php {echo $mostrar['descripcion']; }?></td>
			<td><?php {echo $mostrar['link_video']; }?></td>
			<td><?php {echo $mostrar['estreno']; }?></td>
			<td><?php {echo $mostrar['link_imagen']; }?></td>
			<td><?php {echo $mostrar['taquillero']; }?></td>
			<td><?php {echo $mostrar['actores']; }?></td>
			<td><?php {echo $mostrar['director']; }?></td>
			<td><?php {echo $mostrar['pais']; }?></td>
			<td><?php {echo $mostrar['año']; }?></td>
			<td><?php {echo $mostrar['genero']; }?></td>
			
		</tr>
	<?php 
	}
	 ?>
	</table>
	<a href='../INTERFAZ/interfaz.html''>Volver</a>

</body>
</html>