

<!--Fernando Sanchez Morales
	Realizaremos las respectivas consultas que el usuario quiera efectuar por medio de el id de la pelicula-->

<?php #inicializacion del codigo php
  require_once "../../../biblioteca.php";//llamamos a la biblioteca que contiene la conexion
$conexion =conectaDB();//asignamos a una variable la conexion a la base de datos

?>

<!DOCTYPE html>
<html>
<head>
	<title>mostrar datos</title>
</head>
<!-- En esta seccion definimos los estilos para la tabla que vamos a crear-->
<body style="background-color:#FFFFFF;">
<div style="display: flex;  justify-content: flex-start; " >
	<div style="display: flex;" >
		<img src="../../../../imagenes/logo.png" height="180px" width="180px">
	</div>
	<div style="display: flex;width:580px;height:180px;background-color:#FFFFFF  "> </div>
	<div style="display: flex; align-items: center; ">
		<strong><h2 >ADMINISTRADOR</h2></strong>
	</div>
</div>

<!-- En esta seccion definimos el margen de la tabla-->
<div style="margin-top: 50px">
	<table border="1" >
		<tr>
			<!--Se crea la tabla con sus respectivos campos-->
			<td bgcolor="#0dcfac"> id pelicula</td>
			<td  bgcolor="#0dcfac">nombre</td>
			<td  bgcolor="#94a993">descripcion</td>
			<td bgcolor="#94a993">linkvideo</td>
			<td bgcolor="#94a993">estreno</td>
			<td bgcolor="#94a993">linkimagen</td>
			<td bgcolor="#94a993">taquillero</td>
			<td bgcolor="#94a993">actores</td>
			<td bgcolor="#94a993">director</td>
			<td bgcolor="#94a993">pais</td>
			<td bgcolor="#94a993">año</td>
			<td bgcolor="#94a993">genero</td>
			
		</tr>
		<!-- En esta se realiza una accion en php en que realizaremos una consulta sql para que se muestre cada uno de los campos de nuestra base de datos-->
		<?php 
		$sql="SELECT * from cartelera";
		$result=mysqli_query($conexion,$sql);
		$numero = 0;
		while($mostrar=mysqli_fetch_array($result) ){
		?>
		<tr >		
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['id_pelicula']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['nombre']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['descripcion']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo  $mostrar['link_video']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['estreno']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['link_imagen']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['taquillero']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['actores']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['director']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['pais']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['año']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['genero']; }?></td>
			
		</tr>
	<?php }?>
	</table>
	<!-- se crea un link para poder regresar a la pagina anterior-->

<a href='../INTERFAZ/interfaz.html'>Volver</a>

</div>

	
</body>

</html>