<?php

//realizamos la conexion de la base de datos, al usar una funcion que realiza la conexion y ademas guarda en una variable si se logra conectar o no.
     require_once "../../../biblioteca.php";//llamamos a la biblioteca que contiene la conexion
$conectar =conectaDB();//asignamos a una variable la conexion a la base de datos



	
//recuperamos las variables
	$nombre=$_POST['nombre'];
	//$id_pelicula;
	$horario=$_POST['horario'];
	$estreno=$_POST['estreno'];
	$linkvideo=$_POST['linkvideo'];
	$linkimagen=$_POST['linkimagen'];
	$taquillero=$_POST['taquillero'];
	$descripcion=$_POST['descripcion'];
	$actores = $_POST['actores'];
	$director = $_POST['director'];
	$pais = $_POST['pais'];
	$anio = $_POST['anio'];
	$genero = $_POST['genero'];	
	$sala="000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
	
	//Se pregunta si los siguientes campos fueron seleccionados, de no ser asi asignarles 0
	if($horario==NULL){
	   $horario="00:00"; 
	}
	if($estreno==NULL){
	    $estreno=0;
	}
	if($taquillero==NULL){
	   $taquillero=0; 
	}
    if($anio==NULL){
        $anio=0000;
    }

	//hacemos la sentencia de sql
	$sql="INSERT INTO cartelera (nombre,actores,director,pais,año,genero,link_imagen,taquillero,estreno,link_video,descripcion) VALUES('$nombre','$actores','$director','$pais','$anio','$genero','$linkimagen','$taquillero','$estreno','$linkvideo','$descripcion')";
	

	//ejecutamos la sentencia de sql conectandolo a la base de datos, usando una funcion que
	//la conecta y ademas guarda en una variable si se logra ejecutar o del contrario que hubo un error 
	$ejecutar=mysqli_query($conectar,$sql);       	//verificamos la ejecucion
	if(!$ejecutar){
		echo"Hubo Algun Error";
	}else{
		echo"Datos Guardados Correctamente<br><a href='insertarPeliculas.html'>Volver</a>";
	}
	
		$sql="SELECT * from cartelera";
		$res=mysqli_query($conectar,$sql);
		while($most=mysqli_fetch_array($res) ){
		        $num = $most['id_pelicula']; 
		}



	
	
	$sql="INSERT INTO  funciones (id_pelicula,sala,horario) VALUES('$num','$sala','$horario')";

	//ejecutamos la sentencia de sql conectandolo a la base de datos, usando una funcion que
	//la conecta y ademas guarda en una variable si se logra ejecutar o del contrario que hubo un error 
	$ejecutar=mysqli_query($conectar,$sql);       	//verificamos la ejecucion
	if(!$ejecutar){
		echo"Hubo Algun Error";
	}else{
		//echo"Datos Guardados Correctamente<br><a href='insertarPeliculas.html'>Volver</a>";
	}
	
?>