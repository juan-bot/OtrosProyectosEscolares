
<!--Fernando Sanchez Morales
	Realizaremos las respectivas consultas que el usuario quiera efectuar por medio de el id de la pelicula-->

<?php #inicializacion del codigo php
  require_once "../../../biblioteca.php";//llamamos a la biblioteca que contiene la conexion
$conexion =conectaDB();//asignamos a una variable la conexion a la base de datos

?>

<!DOCTYPE html>
<html>
<head>
	<title>mostrar datos</title>
	 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"><!-- compatiblilidad para todo tipo de dispositivos -->
    <link rel="stylesheet" href="css/estilo3.css"><!-- importacion de carpeta de estilos -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!-- Font Awesome -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
	<!-- Bootstrap core CSS -->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
	<!-- Material Design Bootstrap -->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.10.1/css/mdb.min.css" rel="stylesheet">
 
</head>
<!-- En esta seccion definimos los estilos para la tabla que vamos a crear-->

<body style="background-color:#FFFFFF;">
<div style="display: flex;  justify-content: flex-start; " >
	<div style="display: flex;" >
		<img src="../../../imagenes/logo.png" height="180px" width="180px">
	</div>
	<div style="display: flex;width:580px;height:180px;background-color:#FFFFFF "> </div>
	<div style="display: flex; align-items: center; ">
		<strong><h1 >Modificar pelicula</h1></strong>
	</div>
</div>
<div style="margin-top: 50px
">
	
	<table border="1" >
		<tr >
			<td bgcolor="#0dcfac"> id pelicula</td>
			<td  bgcolor="#0dcfac">nombre</td>
			<td  bgcolor="#94a993">descripcion</td>
			<td bgcolor="#94a993">linkvideo</td>
			<td bgcolor="#94a993">estreno</td>
			<td bgcolor="#94a993">linkimagen</td>
			<td bgcolor="#94a993">taquillero</td>
			<td bgcolor="#94a993">actores</td>
			<td bgcolor="#94a993">director</td>
			<td bgcolor="#94a993">pais</td>
			<td bgcolor="#94a993">año</td>
			<td bgcolor="#94a993">genero</td>
			
		</tr>

<!-- En esta seccion se va a realizar una consulta sql para que nos pueda mostrar los campos de la base de datos de nuestra tabla cartelera -->
		<?php 
		$sql="SELECT * from cartelera";
		
		$result=mysqli_query($conexion,$sql);


		while($mostrar=mysqli_fetch_array($result) ){

		?>
		 	
		<tr >		
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['id_pelicula']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['nombre']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['descripcion']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['link_video']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['estreno']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['link_imagen']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['taquillero']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['actores']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['director']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['pais']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['año']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['genero']; }?></td>
			

		</tr>
	<?php 
	}
	 ?>
	</table>
</div>

<body background>
		<div class="Form">
			<form action="muestraTabla.php" method="POST">
				<!-- En esta seccion del form que abarca a las siguientes acciones para pedir datos, se envia el formulario utilizando el método "POST" en el que utilizaremos el archivo guardar.php para realizar las acciones a la base de datos que seria mandarle las peliculas con codigo sql que es con la que trabajamos para la base de datos-->
			
				<br>
				<br>

		<div style="display: flex;  justify-content: flex-start; " >
	<div style="display: flex;" >
	</div>
	<div style="display: flex;width:580px;height:180px;background-color:#FFFFFF "> </div>
	<div style="display: flex; align-items: center; ">
		<strong><h3>Introducir id de la pelicula a buscar</h3></strong>
	</div>
</div>		
			<div class="container" style="background:#e5dfcd ">
			<div class="row">
		         <div class="col-lg-4" >
        				<!--En esta seccion se establecera un bufer de tipo number para que el usuario pueda intoducir el id de la pelicula-->
 			 	<br>
 			 	<label for="id">id de la pelicula</label>				
				<input type="number" name="id_pelicula" placeholder="numero" required>
 			 	
				<!--En esta seccion se establecera un bufer de tipo text para que el usuario pueda intoducir el nombre de la pelicula-->
				<br><br>
				<label for="Nombre">Nombre de la pelicula</label>		
				<br>
				<input type="text" name="n" placeholder="Nombre" value="">
				
				<br>
				<!--En esta seccion se establecera un bufer de tipo text para que el usuario pueda intoducir el horario1 de la pelicula-->
				<label for="horario">Horario</label>
				<br>
				<input type="text" name="h" placeholder="hora:min" value="">
					<!--En esta seccion se establecera un bufer de tipo text para que el usuario pueda intoducir el horario2 de la pelicula-->	
				<br>
				<label for="estreno">Estreno</label>
				<br>
				<input type="number" name="e" placeholder="numero" value="">
				
				<!--En esta seccion se establecera un bufer de tipo text para que el usuario pueda intoducir el link del video de la pelicula correspondiente -->
				<br>
				<label for="linkvideo">link_video</label>
				<br>
				<input type="text" name="v" placeholder="" value="">		
				</div>


				<div class="col-lg-4" >
 				<br><br><br>
 					<!--En esta seccion se establecera un bufer de tipo text para que el usuario pueda intoducir el link_imagen de la pelicula-->
				<label for="linkimagen">link_imagen</label>
				<br>
				<input type="text" name="i" placeholder="" value="">
				<br>
					<!--En esta seccion se establecera un bufer de tipo number para que el usuario pueda intoducir el campo taquillero de la pelicula-->
				<label for="taquillero">taquillero</label>
				<br>
				<input type="number" name="t" placeholder="numero" value="">
				
				<br>
					<!--En esta seccion se establecera un bufer de tipo text para que el usuario pueda intoducir los actores de la pelicula-->
				<label for="actores">actores</label>
				<br>
				<input type="text" name="actores" placeholder="actores" value="">	
					<!--En esta seccion se establecera un bufer de tipo text para que el usuario pueda intoducir el director de la pelicula-->
				<br>
				<label for="director">director</label>
				<br>
				<input type="text" name="director" placeholder="numero" value="">	
					<!--En esta seccion se establecera un bufer de tipo text para que el usuario pueda intoducir el pais de la pelicula-->
				
				</div>
				<div class="col-lg-2" >

				<br><br><br><br>
				<label for="pais">pais</label>
				<br>
				<input type="text" name="pais" placeholder="pais" value="">
					<!--En esta seccion se establecera un bufer de tipo number para que el usuario pueda intoducir el año de la pelicula-->
				<br>
				<label for="año">año</label>
				<br>
				<input type="number" name="año" placeholder="numero" value="">
				<br>
					<!--En esta seccion se establecera un bufer de tipo text para que el usuario pueda intoducir el genero de la pelicula-->
				<label for="genero">genero</label>
				<br>
				<input type="text" name="genero" placeholder="genero" value="">
				<br>
				</div>
				<div class="col-lg-4" >
				<br>

				<br>
				<!--En esta seccion se establecera un bufer en el que el usuario pueda introducir la descripcion de la pelicula -->
					<label for="descripcion">descripcion</label>
				<br>
				<textarea name="d" placeholder="descripcion" value="" cols="130" rows="7"></textarea>
				
					<!--En esta seccion se establecera un bufer de tipo text para que el usuario pueda intoducir la sala1 de la pelicula-->
					<!--En esta seccion se establecera un bufer de tipo text para que el usuario pueda intoducir el horario1 de la pelicula-->
				<input type="submit" value="		MODIFICAR	">
				<a href='../INTERFAZ/interfaz.html'>Volver</a>
				
				</div>
			</div>


       </div>
<div>
		</form>
		</div>
	


</body>
</html>