

<!--Fernando Sanchez Morales
	Realizaremos las respectivas consultas que el usuario quiera efectuar por medio de el id de la pelicula-->

<?php #inicializacion del codigo php
  require_once "../../../biblioteca.php";//llamamos a la biblioteca que contiene la conexion
$conexion =conectaDB();//asignamos a una variable la conexion a la base de datos

?>

<!DOCTYPE html>
<html>
<head>
	<title>Mostrar datos</title>
</head>

<body style="background-color:#FFFFFF;">
<div style="display: flex;  justify-content: flex-start; " >
	<div style="display: flex;" >
		<img src="../../../imagenes/logo.png" height="180px" width="180px">
	</div>
	<div style="display: flex;width:580px;height:180px;background-color:#FFFFFF  "> </div>
	<div style="display: flex; align-items: center; ">
		<strong><h1 >Mostrar datos</h1></strong>
	</div>
</div>

<div style="margin-top: 50px">
	<table border="1" >
			<td bgcolor="#0dcfac"> id pelicula</td>
			<td  bgcolor="#0dcfac">nombre</td>
			<td  bgcolor="#94a993">descripcion</td>
			<td bgcolor="#94a993">linkvideo</td>
			<td bgcolor="#94a993">estreno</td>
			<td bgcolor="#94a993">linkimagen</td>
			<td bgcolor="#94a993">taquillero</td>
			<td bgcolor="#94a993">actores</td>
			<td bgcolor="#94a993">director</td>
			<td bgcolor="#94a993">pais</td>
			<td bgcolor="#94a993">año</td>
			<td bgcolor="#94a993">genero</td>


	<?php
	
		
		
		$numero = $_POST['id_pelicula'];

		$n = $_POST['n'];
		$h = $_POST['h'];
		$e = $_POST['e'];
		$v = $_POST['v'];
		$i = $_POST['i'];
		$t = $_POST['t'];
		$d = $_POST['d'];
		$actores = $_POST['actores'];
		$director = $_POST['director'];
		$pais = $_POST['pais'];
		$año = $_POST['año'];
		$genero = $_POST['genero'];		
		



//	$sql="DELETE FROM estrenos WHERE estrenos.id_pelicula=$numero";

	//	$ejecutar=mysqli_query($conexion,$sql);       	//verificamos la ejecucion
	//	if(!$ejecutar){
	//		echo"Hubo Algun Error";
	//	}else{
	//		echo"Datos 	eliminado Correctamente";
	//	}


		
			
		//}
$num=-1;

		$sql="SELECT * from cartelera";
		$res=mysqli_query($conexion,$sql);
		while($most=mysqli_fetch_array($res) ){
		
		 	if($most['id_pelicula']== $numero){$num = $most['id_pelicula']; }

}


//se modifica el nombre de la pelicula----------------------------------------------------------------------------------------------------
		if($n!=NULL && $num==$numero){
			$sql="UPDATE cartelera SET nombre = '$n' WHERE cartelera.id_pelicula = $numero";

			$ejecutar=mysqli_query($conexion,$sql);       	//verificamos la ejecucion
				if(!$ejecutar){
					echo"ERROR NOMBRE NO ELIMINADO<br>";
				}else{
					echo"";
				}
		}
		
		
//Se modifica la descripcion de la pelicula-------------------------------------------------------------------------

			if($d!=NULL && $num==$numero){
				$sql="UPDATE cartelera SET descripcion = '$d' WHERE cartelera.id_pelicula = $numero";
				$ejecutar=mysqli_query($conexion,$sql);       	//verificamos la ejecucion
				if(!$ejecutar){
					echo"ERROR DESCRIPCION NO ELIMINADO<br>";
				}else{
					echo"";
				}
			}
			

//se modifica el link video------------------------------------------------------------------------------------------			
				if($v!=NULL && $num==$numero){
					$sql="UPDATE cartelera SET link_video = '$v' WHERE cartelera.id_pelicula = $numero";
					$ejecutar=mysqli_query($conexion,$sql);       	//verificamos la ejecucion
					if(!$ejecutar){
						echo"LINK VIDEO NO ELIMINADO<br>";
					}else{
						echo"";
					}
				}
				
//Se modifica estreno

				if($e!=NULL && $num==$numero){
					$sql="UPDATE cartelera SET estreno = '$e' WHERE cartelera.id_pelicula = $numero";
					$ejecutar=mysqli_query($conexion,$sql);       	//verificamos la ejecucion
					if(!$ejecutar){
						echo"ESTRENOS NO ELIMINADO<br>";
					}else{
						echo"";
					}
				}
				
//Se modifica link inmagen	
				if($i!=NULL && $num==$numero){
					$sql="UPDATE cartelera SET link_imagen = '$i' WHERE cartelera.id_pelicula = $numero";
					$ejecutar=mysqli_query($conexion,$sql);       	//verificamos la ejecucion
					if(!$ejecutar){
						echo"ERROR IMAGEN NO ELIMINADO<br>";
					}else{
						echo"";
					}
				}
				
//Se modifica taquillero	
				if($t!=NULL && $num==$numero){
					$sql="UPDATE cartelera SET taquillero = '$t' WHERE cartelera.id_pelicula = $numero";
					$ejecutar=mysqli_query($conexion,$sql);       	//verificamos la ejecucion
					if(!$ejecutar){
						echo"ERROR TAQUILLERO NO ELIMINADO";
					}else{
						echo"";
					}
				}
				
//Se modifica horario1
				if($h!=NULL && $num==$numero){
				$sql="UPDATE cartelera SET horario = '$h' WHERE cartelera.id_pelicula = $numero";
				$ejecutar=mysqli_query($conexion,$sql);       	//verificamos la ejecucion
					if(!$ejecutar){
						echo"ERROR HORARIO NO ELIMINADO<br>";
					}else{
						echo"";
					}
				}
				
					if($actores!=NULL && $num==$numero){
				$sql="UPDATE cartelera SET actores = '$actores' WHERE cartelera.id_pelicula = $numero";
				$ejecutar=mysqli_query($conexion,$sql);       	//verificamos la ejecucion
					if(!$ejecutar){
						echo"ERROR HORARIO6 NO ELIMINADO<br>";
					}else{
						echo"";
					}
				}

				
					if($director!=NULL && $num==$numero){
					$sql="UPDATE cartelera SET director = '$director' WHERE cartelera.id_pelicula = $numero";
					$ejecutar=mysqli_query($conexion,$sql);       	//verificamos la ejecucion
						if(!$ejecutar){
							echo"ERROR DIRECTOR NO ELIMINADO<br>";
					}else{
						echo"";
					}
				}
					
						if($pais!=NULL && $num==$numero){
							$sql="UPDATE cartelera SET pais = '$pais' WHERE cartelera.id_pelicula = $numero";
							$ejecutar=mysqli_query($conexion,$sql);       	//verificamos la ejecucion
							if(!$ejecutar){
								echo"ERROR PAIS NO ELIMINADO<br>";
							}else{
								echo"";
							}
						}

						
							if($año!=NULL && $num==$numero){
							$sql="UPDATE cartelera SET año = '$año' WHERE cartelera.id_pelicula = $numero";
							$ejecutar=mysqli_query($conexion,$sql);       	//verificamos la ejecucion
							if(!$ejecutar){
								echo"ERROR AÑO NO ELIMINADO<br>";
							}else{
								echo"";
							}
						}

					
							if($genero!=NULL && $num==$numero){
							$sql="UPDATE cartelera SET genero = '$genero' WHERE cartelera.id_pelicula = $numero";
							$ejecutar=mysqli_query($conexion,$sql);       	//verificamos la ejecucion
							if(!$ejecutar){
								echo"ERROR GENERO NO ELIMINADO<br>";
							}else{
								echo"";
							}
						}
						
								
?>


		<?php 
	
		$sql="SELECT * from  cartelera";
		$result=mysqli_query($conexion,$sql);

		while($mostrar=mysqli_fetch_array($result) ){
		?>
		 	
		<tr>
			<td><?php {echo $mostrar['id_pelicula']; }?></td>
			<td><?php {echo $mostrar['nombre']; }?></td>
			<td><?php {echo $mostrar['descripcion']; }?></td>
			<td><?php {echo $mostrar['link_video']; }?></td>
			<td><?php {echo $mostrar['estreno']; }?></td>
			<td><?php {echo $mostrar['link_imagen']; }?></td>
			<td><?php {echo $mostrar['taquillero']; }?></td>
			<td><?php {echo $mostrar['actores']; }?></td>
			<td><?php {echo $mostrar['director']; }?></td>
			<td><?php {echo $mostrar['pais']; }?></td>
			<td><?php {echo $mostrar['año']; }?></td>
			<td><?php {echo $mostrar['genero']; }?></td>
			
		</tr>
	<?php 
	}
	 ?>
	</table>
	<a href='../INTERFAZ/interfaz.html''>Volver</a>

</body>
</html>