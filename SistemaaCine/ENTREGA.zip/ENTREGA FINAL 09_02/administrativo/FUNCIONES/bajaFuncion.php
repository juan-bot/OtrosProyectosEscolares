<!--Vazquez Garcia Brenda Yasel-->	
<?php #inicializacion del codigo php
  require_once "../../biblioteca.php";//llamamos a la biblioteca que contiene la conexion
$conexion =conectaDB();//asignamos a una variable la conexion a la base de datos

?>
<!-- Prototipo en el cual se podra dar de baja una funcion-->
<!DOCTYPE html>
<html>
	<head>
   <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"><!-- compatiblilidad para todo tipo de dispositivos -->
    <!-- importacion de carpeta de estilos -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!-- Font Awesome -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
	<!-- Bootstrap core CSS -->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
	<!-- Material Design Bootstrap -->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.10.1/css/mdb.min.css" rel="stylesheet">
 
		<title>ELIMINAR FUNCION </title>
		
	</head>
	
	<body background><!-- En esta seccion definimos el margen de la tabla-->
	
				<h2>Baja de funcion</h2>
<div style="margin-top: 50px">
	<table border="1" align="center">
		<tr >
			<!--Se crea la tabla con sus respectivos campos-->
			<td bgcolor="#0dcfac"> id_funcion</td>
			<td bgcolor="#0dcfac">id_pelicula</td>
			<td  bgcolor="#0dcfac">sala</td>
			<td  bgcolor="#0dcfac">horario</td>
		</tr>
		<!-- En esta se realiza una accion en php en que realizaremos una consulta sql para que se muestre cada uno de los campos de nuestra base de datos-->
		<?php 
		$sql="SELECT * from funciones";
		$result=mysqli_query($conexion,$sql);
		$numero = 0;
		while($mostrar=mysqli_fetch_array($result) ){//mientras haya datos, los imprimimos
		?>
		<tr >		<!-- imprimimos los datos  -->
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['id_funcion']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['id_pelicula']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['sala']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['horario']; }?></td>

		</tr>
	<?php }?>
	</table>
		<div class="Form">
			<form action="guardarBajaFuncion.php" method="POST">
				<!-- En esta seccion del form que abarca a las siguientes acciones para pedir datos, se envia el formulario utilizando el método "POST" en el que utilizaremos el archivo guardarBBajaFuncion.php para realizar las acciones a la base de datos-->
				<br>
			<div class="container" style="background:#e5dfcd ">
			<div class="row">
		         <div class="col-lg-4" >
        				<!--En esta seccion se establecera un bufer de tipo texto para que el usuario pueda intoducir el id de la funcion-->
				<label for="id_pelicula">id de la funcion</label>
				<br>
				<input type="number" name="id" placeholder="id funcion" required>
			
				<br>


				<input type="submit" value="	ELIMINAR 		">
				<br>
		
			<a href='../CARTELERA/INTERFAZ/interfaz.html'>Volver</a>
					</DIV>
			</div>
			</div>
		</form>
		</div>
	</body>
</html>