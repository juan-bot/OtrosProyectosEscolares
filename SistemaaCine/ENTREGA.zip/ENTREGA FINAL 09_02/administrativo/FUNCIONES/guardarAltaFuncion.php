<!--Vazquez Garcia Brenda Yasel-->		
<?php

//realizamos la conexion de la base de datos, al usar una funcion que realiza la conexion y ademas guarda en una variable si se logra conectar o no.
require_once "../../biblioteca.php";//llamamos a la biblioteca que contiene la conexion
$conexion =conectaDB();//asignamos a una variable la conexion a la base de datos



	
//recuperamos las variables
	$id_pelicula=$_POST['id_pelicula'];
	$sala=$_POST['sala'];
	$horario1=$_POST['horario1'];
	
	//hacemos la sentencia de sql
	$sql="INSERT INTO  funciones (id_pelicula,sala,horario) VALUES('$id_pelicula','$sala','$horario1')";
	//ejecutamos la sentencia de sql conectandolo a la base de datos, usando una funcion que
	//la conecta y ademas guarda en una variable si se logra ejecutar o del contrario que hubo un error 
	$ejecutar=mysqli_query($conexion,$sql);       	//verificamos la ejecucion
	if(!$ejecutar){
		echo"Hubo Algun Error";
	}else{
		echo"Datos Guardados Correctamente<br><a href='altaFuncion.html'>Volver</a>";
	}
?>