<!--HERNANDEZ SANTOS MARCO ANTONIO-->		

<?php

//realizamos la conexion de la base de datos, al usar una funcion que realiza la conexion y ademas guarda en una variable si se logra conectar o no.
require_once "../../biblioteca.php";//llamamos a la biblioteca que contiene la conexion
$conexion =conectaDB();//asignamos a una variable la conexion a la base de datos



	
//recuperamos las variables
	$id_pelicula=$_POST['id'];


	//hacemos la sentencia de sql
	$sql="DELETE FROM promociones WHERE id=$id_pelicula";
	//ejecutamos la sentencia de sql conectandolo a la base de datos, usando una funcion que
	//la conecta y ademas guarda en una variable si se logra ejecutar o del contrario que hubo un error 
	$ejecutar=mysqli_query($conexion,$sql);       	//verificamos la ejecucion
	if(!$ejecutar){
		echo"Hubo Algun Error";
	}else{
		echo"Datos Guardados Correctamente<br><a href='BajaPromo.php'>Volver</a>";
	}
?>