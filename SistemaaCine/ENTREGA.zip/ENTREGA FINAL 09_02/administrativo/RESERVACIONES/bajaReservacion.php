<!--VAZQUEZ GARCIA BRENDA YASEL-->	
<?php #inicializacion del codigo php
  require_once "../../biblioteca.php";//llamamos a la biblioteca que contiene la conexion
$conexion =conectaDB();//asignamos a una variable la conexion a la base de datos

?>
<!DOCTYPE html>
<html>
	<head>
		<!--Se realizara un formulario para pedir al usuario el id de la reservacion que desea eliminar-->
   <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"><!-- compatiblilidad para todo tipo de dispositivos -->
    <!-- importacion de carpeta de estilos -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!-- Font Awesome -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
	<!-- Bootstrap core CSS -->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
	<!-- Material Design Bootstrap -->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.10.1/css/mdb.min.css" rel="stylesheet">
 
		<title>Eliminar reservacion </title>
		
	</head>
	
	<body background>
	<h2>Baja de reservacion</h2>
<!-- En esta seccion definimos el margen de la tabla-->
<div style="margin-top: 50px">
	<table border="1" align="center" >
		<tr >
			<!--Se crea la tabla con sus respectivos campos-->
			<td bgcolor="#0dcfac"> id_pelicula</td>
			<td  bgcolor="#0dcfac">codigo_reservacion</td>

		</tr>
		<!-- En esta se realiza una accion en php en que realizaremos una consulta sql para que se muestre cada uno de los campos de nuestra base de datos-->
		<?php 
		$sql="SELECT * from reservaciones";
		$result=mysqli_query($conexion,$sql);
		$numero = 0;
		while($mostrar=mysqli_fetch_array($result) ){
		?>
		<tr >		
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['id_pelicula']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['codigo_reservaciones']; }?></td>

		</tr>
	<?php }?>
	</table>
	<!-- se crea un link para poder regresar a la pagina anterior-->

</div>

		<div class="Form">
		    
			<form action="guardarBajaReservacion.php" method="POST">
				<!-- En esta seccion del form , se envia el formulario utilizando el método "POST" en el que utilizaremos el archivo guardarBajaReservacion.php para realizar las acciones a la base de datos mandandole el id con codigo sql que es con la que trabajamos para la base de datos-->
			
				<br>
			<div class="container" style="background:#e5dfcd ">
			<div class="row">
		         <div class="col-lg-4" >
        				<!--En esta seccion se establecera un bufer de tipo texto para que el usuario pueda intoducir el codigo de reservacion-->
				<label for="id_pelicula">codigo de la reservacion</label>
				<br>
				<input type="number" name="id" placeholder="codigo reservacion" required>
			
				<br>


				<input type="submit" value="	ELIMINAR		">
				<br>
			<a href='../CARTELERA/INTERFAZ/interfaz.html'>Volver</a>
					</DIV>
			</div>
			</div>
		</form>
		</div>
	</body>
</html>