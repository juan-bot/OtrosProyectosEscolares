<!--VAZQUEZ GARCIA BBRENDA YASEL-->	
<?php #inicializacion del codigo php
  require_once "../../biblioteca.php";//llamamos a la biblioteca que contiene la conexion
$conexion =conectaDB();//asignamos a una variable la conexion a la base de datos
?>
<!--prototipo mediante el cual, el administrador podra realizar la consulta de las reservaciones -->
<!DOCTYPE html>
<html>
<head>
	<title>mostrar reservaciones</title><!-- titulo de la pagina -->
</head>
<!-- En esta seccion definimos los estilos para la tabla que vamos a crear-->
<body style="background-color:#FFFFFF;">
<div style="display: flex;  justify-content: flex-start; " >
	<div style="display: flex;" >
		<img src="../../imagenes/logo2.png" height="180px" width="180px">
	</div>
	<div style="display: flex;width:580px;height:180px;background-color:#FFFFFF  "> </div>
	<div style="display: flex; align-items: center; ">
		<strong><h1 >ADMINISTRADOR</h1></strong>
	</div>
</div>

<!-- En esta seccion definimos el margen de la tabla-->
<div style="margin-top: 50px">
	<table border="1" >
		<tr >
			<!--Se crea la tabla con sus respectivos campos-->
			<td bgcolor="#0dcfac"> id_pelicula</td>
			<td  bgcolor="#0dcfac">codigo_reservacion</td>

		</tr>
		<!-- En esta se realiza una accion en php en que realizaremos una consulta sql para que se muestre cada uno de los campos de nuestra base de datos-->
		<?php 
		$sql="SELECT * from reservaciones";
		$result=mysqli_query($conexion,$sql);
		$numero = 0;
		while($mostrar=mysqli_fetch_array($result) ){//mientras haya datos, los imprimimos
		?>
		<tr >		
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['id_pelicula']; }?></td>
			<td bgcolor="#FFFFFF"><?php {echo $mostrar['codigo_reservaciones']; }?></td>

		</tr>
	<?php }?>
	</table>
	<!-- se crea un link para poder regresar a la pagina anterior-->

			<a href='../CARTELERA/INTERFAZ/interfaz.html'>Volver</a>

</div>

	
</body>

</html>