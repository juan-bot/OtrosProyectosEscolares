<!--Ramos Zosayas.  Interfaz que muestra las promociones -->
<?php
require_once "biblioteca.php";//llamamos a la biblioteca que contiene la conexion
$conexion =conectaDB();//asignamos a una variable la conexion a la base de datos
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"><!-- compatiblilidad para todo tipo de dispositivos -->
        <link rel="stylesheet" href="css/estilo.css"><!-- importacion de carpeta de estilos -->

    <link rel="stylesheet" href="css/estiloEst.css"><!-- importacion de carpeta de estilos -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.10.1/css/mdb.min.css" rel="stylesheet">
    <title>Proximos Estrenos</title>
  </head><!--  -->
  <body >
  <!-- class barra1 es el contenedor principal del menu -->
  <nav class="navbar navbar-expand-lg navbar-dark sticky-top" style="background-color: #232329;">
    <a class="navbar-brand" text-white href='index.php'>
      CINEMA 4</a><!--  integracion del logo en el menu-->
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent" id="menu">
      	<ul class="navbar nav ml-auto">
          <li class="nav-item ">
            <!--referencia a las opciones del menu para identificarlos al momento de que se requiera una accion con ellos  -->
            <a href='index.php'  class="nav-link text-light">INICIO</a>
          </li>
          <li class="nav-item ">
            <a  href='Cartelera.php' class="nav-link text-light">CARTELERA</a>
          </li>
          <li class="nav-item ">
            <a href='Promociones.php' class="nav-link text-light">PROMOCIONES</a>
          </li>
          <li class="nav-item ">
            <a href="proximosEstrenos.php" class="nav-link text-light">PROXIMOS ESTRENOS</a>
          </li>

        </ul>
    </div>
  </nav>
<img src='imagenes/E4.jpg' width="100%" height="50%" />
  <br><br><br>
  </div>
<section  id="Estrenos de la semana" class="container">
    <div clas="col-lg-4" >
      <br><br>
    </div>
</section>




  <section id="pSeleccionada" class="container"><!-- contenedor de las imagenes -->
    <div class="row">

      
      <?php
    $sql="SELECT * from cartelera where estreno=0";
    $result=mysqli_query($conexion,$sql);
    while($mostrar=mysqli_fetch_array($result) ){
    #inicializacion del codigo php
          //$var1=$_GET['variable'];;
    ?>
    <div class="col-lg-3">  <!--Espacio entre imagen y sinopsis-->
    <?php
    echo '<img  src="'.$mostrar['link_imagen'].'">';#muestra la imagen obtenida de la base de datos
    ?>
    
    </div>
        <div class="col-lg-4">
          <br>
          <div class="container"><h3 align="center">Sinopsis</h3></div>
          <?php #inicializacion del codigo php
         echo '<p>'.$mostrar['descripcion'].'</p>';#muestra la descripcion obtenida de la base de datos
        ?>
        <br>
      </div>

      <div class="col-lg-1"> </div>   <!--espacio entre Sinopsis y video-->
      <div class="col-lg-2">         <!--numero de columnas de video-->
          <div class="barra" >
              <br>
              <div id="linkTrailer">
                <?php #inicializacion del codigo php
                 #inicializacion de variable que sirve como id
                echo '<iframe src="'.$mostrar['link_video'].'"frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';#muestra el video obtenido de la base de datos
              ?>
            </div>
            </div>
      </div>

    <?php 
    }
   ?>

    </div>
    <br><br><hr>
  </section>

   <div class="Propiedad">
    <div class="row">
        
    <div class="col-lg-4"> 
      <img src='imagenes/cinco.png'  class="Imagenpromo"> 
    </div>
    
    <div class="col-lg-4"> 
     <img src='imagenes/cuatro.png'  class="Imagenpromo"> 
    </div>
    
    <div class="col-lg-4"> 
     <img src='imagenes/dos.png'  class="Imagenpromo">
     </div> 
    
    <div class="col-lg-4"> 
     <img src='imagenes/tres.png'  class="Imagenpromo">
     </div>  
     
     <div class="col-lg-4"> 
     <img src='imagenes/treinta.png'  class="Imagenpromo">
     </div> 
     
     <div class="col-lg-4"> 
     <img src='imagenes/ochenta.png'  width='40%' class="Imagenpromo">
     </div> 
     
    
    </div>
    </div>




    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <!-- JQuery -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.10.1/js/mdb.min.js"></script>
  </body>
</html>
