<!--fernando sanchez morales  -->

<?php #inicializacion del codigo php
  require_once "biblioteca.php";//llamamos a la biblioteca que contiene la conexion
$conexion =conectaDB();//asignamos a una variable la conexion a la base de datos

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"><!-- compatiblilidad para todo tipo de dispositivos -->
    <link rel="stylesheet" href="css/estilo3.css"><!-- importacion de carpeta de estilos -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!-- Font Awesome -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
<!-- Bootstrap core CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
<!-- Material Design Bootstrap -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.10.1/css/mdb.min.css" rel="stylesheet">
    <title>Venta</title>
  </head><!--  -->
  <body >
  <!-- class barra1 es el contenedor principal del menu -->
  


  <nav class="navbar navbar-expand-lg navbar-dark sticky-top" style="background-color: #232329;">
    <a class="navbar-brand" text-white href="#">CINEMA 4
  
    </a>
    
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

<form action="venta.php" method="POST">

<div class="container">
  <div class="collapse" id="collapseExample">
    <div class="card card-body">
  <div class="sala" >
    <div class="pantalla1">
    </div>
       <div>
        <label for="codigo" >codigo</label>
        <input type="text" maxlength="12" name="codigo"  placeholder="codigo" required>
        <input type="submit" value="Enviar">
       </div>
     
</div>
  </div>
</div>

</form>


<div class="collapse navbar-collapse" id="navbarSupportedContent" id="menu">
       <div class="col-lg-12">
        <p style="color:#FF0000">VENTA DE BOLETOS</p>
          <input type='button' name='codigo' value='Reservacion' style='width:100px; height:40px' data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
        </div>
      </div>

  </nav>
<!-- se inserta la imagen aludida a promociones dentro de un contenedor -->
 <div><!-- color de fondo a el contenedor de todas las imagenes de promociones -->
     <br>
 <section id="cartelera" class="container"><!-- contenedor de las imagenes -->
       <div class="row">
           <?php
    $sql="SELECT * from cartelera where estreno=1";//se hace la consulta para phpmyadmin y la guardamos en una variable
    $result=mysqli_query($conexion,$sql);//hacemos la consulta con la ayuda de mysqli_queery
    while($mostrar=mysqli_fetch_array($result) ){//iniciamos el ciclo y le asignamos a una variable lo de la consulta
    ?>
         <div class="col-lg-3 " align ="center"><!--este es para cada una de las imagenes -->
           <a href="InfoPelicula.php?variable=<?php echo urlencode($mostrar['id_pelicula']);?>">
            <?php //echo'<div class="col-lg-3"  align ="center" >';
          echo ' <img  width="10px"  height="260px"  src="'.$mostrar['link_imagen'].'"alt="first slide">';//imprimimos la imagen ,de la variable mostrar nosotros vamos a escojer el campo link_imagen
          echo '<h6 align ="center"><strong>'.$mostrar['nombre'].'<br><br></strong></h6>';
          //de igual forma nosotros vamos a mostrar de la variable mostrar solo nos interesa el nombre y eso lo imprimimos junto con codigo html
          //$variable=+1;?>
           </a>
           
         </div>
    <?php
    }//ceramos el ciclo while 
    ?>  
       </div>
     </section>

      <br>
   </div>

<div class="container">
  <div class="collapse" id="collapseExample">
    <div class="card card-body">
      <div class="row">
        <div class="col-lg-3">
          <img src="imagenes/asiento1.jpg" width="25%">
          <h6>Disponible</h6>
        </div>
        <div class="col-lg-2">
          <img src="imagenes/asiento2.jpg" width="30%">
          <h6>Ocupado</h6>
        </div>
        <div class="col-lg-2">
          <img src="imagenes/asiento3.jpg" width="25%">
          <h6>Elegido</h6>
        <div class="col-lg-5">
          <img src="imagenes/pantalla.jpeg" width="100%">
          <h6>Pantalla</h6>
        </div>
      </div>
      </div>
      <br>
      <div class="sala">
        <div class="pantalla1 col-lg-12">
      </div>
      <br><br>
        <table>
          <tr>
            <td>
              <a  id="00" class="asiento" onclick="selec(0,0)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="01" class="asiento" onclick="selec(0,1)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="02" class="asiento" onclick="selec(0,2)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="03" class="asiento" onclick="selec(0,3)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="04" class="asiento" onclick="selec(0,4)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="05" class="asiento" onclick="selec(0,5)"><img src='imagenes/asiento1.jpg'width="100%"></a>
            </td>
            <td>
              <a  id="06" class="asiento" onclick="selec(0,6)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="07" class="asiento" onclick="selec(0,7)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="08" class="asiento" onclick="selec(0,8)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="09" class="asiento" onclick="selec(0,9)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="010" class="asiento" onclick="selec(0,10)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="011" class="asiento" onclick="selec(0,11)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
          </tr>
          <tr>
            <td>
              <a  id="10" class="asiento" onclick="selec(1,0)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="11" class="asiento" onclick="selec(1,1)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="12" class="asiento" onclick="selec(1,2)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="13" class="asiento" onclick="selec(1,3)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="14" class="asiento" onclick="selec(1,4)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="15" class="asiento" onclick="selec(1,5)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="16" class="asiento" onclick="selec(1,6)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="17" class="asiento" onclick="selec(1,7)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="18" class="asiento" onclick="selec(1,8)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="19" class="asiento" onclick="selec(1,9)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="110" class="asiento" onclick="selec(1,10)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="111" class="asiento" onclick="selec(1,11)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
          </tr><tr>
            <td>
              <a  id="20" class="asiento" onclick="selec(2,0)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="21" class="asiento" onclick="selec(2,1)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="22" class="asiento" onclick="selec(2,2)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="23" class="asiento" onclick="selec(2,3)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="24" class="asiento" onclick="selec(2,4)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a id="25" class="asiento" onclick="selec(2,5)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a id="26" class="asiento" onclick="selec(2,6)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="27" class="asiento" onclick="selec(2,7)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a id="28" class="asiento" onclick="selec(2,8)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="29" class="asiento" onclick="selec(2,9)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="210" class="asiento" onclick="selec(2,10)"><img src='imagenes/asiento1.jpg'width="100%"></a>
            </td>
            <td>
              <a  id="211" class="asiento" onclick="selec(2,11)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
          </tr>
          <tr>
            <td>
              <a id="30" class="asiento" onclick="selec(3,0)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="31" class="asiento" onclick="selec(3,1)"><img src='imagenes/asiento1.jpg'width="100%"></a>
            </td>
            <td>
              <a  id="32" class="asiento" onclick="selec(3,2)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="33" class="asiento" onclick="selec(3,3)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a id="34" class="asiento" onclick="selec(3,4)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a id="35" class="asiento" onclick="selec(3,5)"><img src='imagenes/asiento1.jpg'width="100%"></a>
            </td>
            <td>
              <a  id="36" class="asiento" onclick="selec(3,6)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="37" class="asiento" onclick="selec(3,7)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="38" class="asiento" onclick="selec(3,8)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a id="39" class="asiento" onclick="selec(3,9)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="310" class="asiento" onclick="selec(3,10)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="311" class="asiento" onclick="selec(3,11)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
          </tr>
          <tr>
            <td>
              <a id="40" class="asiento" onclick="selec(4,0)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="41" class="asiento" onclick="selec(4,1)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="42" class="asiento" onclick="selec(4,2)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="43" class="asiento" onclick="selec(4,3)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a id="44" class="asiento" onclick="selec(4,4)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="45" class="asiento" onclick="selec(4,5)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="46" class="asiento" onclick="selec(4,6)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="47" class="asiento" onclick="selec(4,7)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="48" class="asiento" onclick="selec(4,8)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="49" class="asiento" onclick="selec(4,9)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="410" class="asiento" onclick="selec(4,10)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="411" class="asiento" onclick="selec(4,11)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
          </tr><tr>
            <td>
              <a  id="50" class="asiento" onclick="selec(5,0)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="51" class="asiento" onclick="selec(5,1)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="52" class="asiento" onclick="selec(5,2)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="53" class="asiento" onclick="selec(5,3)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="54" class="asiento" onclick="selec(5,4)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="55" class="asiento" onclick="selec(5,5)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="56" class="asiento" onclick="selec(5,6)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="57" class="asiento" onclick="selec(5,7)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="58" class="asiento" onclick="selec(5,8)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="59" class="asiento" onclick="selec(5,9)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="510" class="asiento" onclick="selec(5,10)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a id="511" class="asiento" onclick="selec(5,11)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
          </tr>
          <tr>
            <td>
              <a  id="60" class="asiento" onclick="selec(6,0)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a id="61" class="asiento" onclick="selec(6,1)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="62" class="asiento" onclick="selec(6,2)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a id="63" class="asiento" onclick="selec(6,3)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="64" class="asiento" onclick="selec(6,4)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a id="65" class="asiento" onclick="selec(6,5)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="66" class="asiento" onclick="selec(6,6)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="67" class="asiento" onclick="selec(6,7)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="68" class="asiento" onclick="selec(6,8)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="69" class="asiento" onclick="selec(6,9)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="610" class="asiento" onclick="selec(6,10)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="611" class="asiento" onclick="selec(6,11)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
          </tr>
          <tr>
            <td>
              <a  id="70" class="asiento" onclick="selec(7,0)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="71" class="asiento" onclick="selec(7,1)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="72" class="asiento" onclick="selec(7,2)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="73" class="asiento" onclick="selec(7,3)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="74" class="asiento" onclick="selec(7,4)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="75" class="asiento" onclick="selec(7,5)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="76" class="asiento" onclick="selec(7,6)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="77" class="asiento" onclick="selec(7,7)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="78" class="asiento" onclick="selec(7,8)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="79" class="asiento" onclick="selec(7,9)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="710" class="asiento" onclick="selec(7,10)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
            <td>
              <a  id="711" class="asiento" onclick="selec(7,11)"><img src='imagenes/asiento1.jpg' width="100%"></a>
            </td>
          </tr>
        </table>
  </div>
</div>
<a class="btn btn-primary"  role="button" aria-expanded="false"  onclick="reservar()">Reservar</a>
  </div>
</div>
  <script src="js/selecciona.js"></script>
  <script src="js/matriz.js"></script>

  
 <script type="text/javaScript">
      	 sala= new Array();
      	ide=([<?php echo $var1; ?>]);
      	function consulta1(){
      		var sala1="sala";
      		var xmlhttp=new XMLHttpRequest();
	        xmlhttp.onreadystatechange=function(){
	        if (this.readyState==4 && this.status==200) {
	             sala=this.responseText;
	            consulta2();
	        }
	        };
	        xmlhttp.open("GET", "consultaSala.php?q=" + sala1+"&d="+ide, true);
	        xmlhttp.send();	
	        
      	}
      </script>
  <script type="text/javaScript">//inicia el codigo javascript
    //var sala= new Array(96),sal= new Array(96);//se declara los arreglos a utilizar
    //LO QUE CORTE ESA EN OTRO  //a la varable sal se le asigna la consulta de la base de datos
    //sala=sal.toString(sal);//convertimos la variable sal a tipo String para poder manipularla
    var i,b=0,c=0;//se inicializan indices que se ocuparan mas adelante
    var bandera=0,seleccionado=0;  //se inicializan variables que se ocuparan mas adelante
      function consulta2(){    //inicia una funcion
      console.log(sala[1]);
      bandera=0,seleccionado=0;
      for(i=0;i<96;i++){ //for para recorrer y manipular nuestra sala que contiene 96 asientos 
        recorre(sala[i],c,b);//llamado a una funcion para recorrer la sala
        if((i+1)%12==0){//divide nuetra sala en filas de 12
          c++;
          b=0;
        }
         else{
           b++;
         }
      }
      b=0;
      c=0;
    }
    </script>

    <script>
      function reservar(){ //inicia funcion reservar
        if(seleccionado==1){//condicion que verifica si un asiento fue seleccionado
          var aux= new Array(96);//inicializa un nuevo arreglo
          for (var i =0; i < 96; i++) { //for para recorrer la sala y asignar el nuevo asiento reservado
            if (sala[i]==0)
              aux[i]=0;
            else
              aux[i]=1;
          }

       
          aux[(cx*12)+cy]=1;//asignacion del nuevo asiento reservado a nuestra sala
          cx=0;
          cy=0;
          var acep=confirm("ASIENTO VENDIDO\n");
          if (acep) {
            update(aux);
            location.href="venta.php";//redirecciona la pagina 
          }

        }
        else{
          alert("DEBES ESCOJER UN ASIENTO")
        }
      }
      function update(aux){
      		
      		var xmlhttp=new XMLHttpRequest();
	        xmlhttp.onreadystatechange=function(){
	        if (this.readyState==4 && this.status==200) {
	             sala=this.responseText;
	        }
	        };
	        console.log(aux);
	        xmlhttp.open("GET", "upDateSala.php?q=" + aux+"&d="+ide, true);
	        xmlhttp.send();	
	        
      	}
    </script>

   





    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.10.1/js/mdb.min.js"></script>

  </body>
</html>
