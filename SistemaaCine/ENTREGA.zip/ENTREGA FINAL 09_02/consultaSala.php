<?php
  	$conexion =mysqli_connect('localhost','root','','menu1');
	$v1=$_GET["q"];
	$d2=$_GET["d"];
	$resulta=mysqli_query($conexion,"SELECT $v1 FROM funciones WHERE id_pelicula=$d2"); #se hace la consulta de las salas y se asigna a una variable
    $consult=$resulta-> fetch_assoc();
    print($consult[$v1]);
?>