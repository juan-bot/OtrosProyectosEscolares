<!--Hernandez Santos Marco Antonio.  Interfaz que muestra las promociones -->
<?php
require_once "biblioteca.php";//llamamos a la biblioteca que contiene la conexion
$conexion =conectaDB();//asignamos a una variable la conexion a la base de datos
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"><!-- compatiblilidad para todo tipo de dispositivos -->
    <link rel="stylesheet" href="css/estilo2.css"><!-- importacion de carpeta de estilos -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!-- Font Awesome -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
<!-- Bootstrap core CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
<!-- Material Design Bootstrap -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.10.1/css/mdb.min.css" rel="stylesheet">
    <title>PROMOCIONES</title>
  </head><!--  -->
  <body >
  <!-- class barra1 es el contenedor principal del menu -->
  <nav class="navbar navbar-expand-lg navbar-dark sticky-top" style="background-color: #232329;">
    <a class="navbar-brand" text-white href='index.php'>CINEMA 4 </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent" id="menu">
      	<ul class="navbar nav ml-auto">
          <li class="nav-item ">
            <!--referencia a las opciones del menu para identificarlos al momento de que se requiera una accion con ellos  -->
            <a href='index.php'  class="nav-link text-light">INICIO</a>
          </li>
          <li class="nav-item ">
            <a href='Cartelera.php' class="nav-link text-light">CARTELERA</a>
          </li>
          <li class="nav-item ">
            <a href='Promociones.php' class="nav-link text-light">PROMOCIONES</a>
          </li>
          <li class="nav-item ">
            <a href="proximosEstrenos.php" class="nav-link text-light">PROXIMOS ESTRENOS</a>
          </li>

        </ul>
    </div>
  </nav>
<!-- se inserta la imagen aludida a promociones dentro de un contenedor -->
   <div class="Barra">
     <img src='img_promo/promociones.jpg' width='77%' class="Imagenpromo">
   </div>
   <div style="background-color:#F7DC6F"><!-- color de fondo a el contenedor de todas las imagenes de promociones -->
     <br>
     <section id="galeria" class="container"><!-- contenedor de las imagenes -->
       <div class="row">


    <?php
    $sql="SELECT * from promociones";//se hace la consulta para phpmyadmin y la guardamos en una variable
		$result=mysqli_query($conexion,$sql);//hacemos la consulta con la ayuda de mysqli_queery
		while($mostrar=mysqli_fetch_array($result) ){//iniciamos el ciclo y le asignamos a una variable lo de la consulta
		?>
         <div class="col-lg-4 col-md-6 col-sm-12"><!--este es para cada una de las imagenes -->
           	<?php
           echo '<img src="'.$mostrar['img_promo'].'"alt="first slide">';//en est aparte se imprime la variable la cual tiene el dato que deseamos despues de haber echo la consulta y lo que hace es imprimir la imagen desde php
            ?>
         </div>
		<?php
		}//ceramos el ciclo while 
		?>	
           
       </div>
       
     </section>
      <br>
   </div>

   <div class="Propiedad">
    <div class="row">
        
    <div class="col-lg-4"> 
      <img src='imagenes/cinco.png'  class="Imagenpromo"> 
    </div>
    
    <div class="col-lg-4"> 
     <img src='imagenes/cuatro.png'  class="Imagenpromo"> 
    </div>
    
    <div class="col-lg-4"> 
     <img src='imagenes/dos.png'  class="Imagenpromo">
     </div> 
    
    <div class="col-lg-4"> 
     <img src='imagenes/tres.png'  class="Imagenpromo">
     </div>  
     
     <div class="col-lg-4"> 
     <img src='imagenes/treinta.png'  class="Imagenpromo">
     </div> 
     
     <div class="col-lg-4"> 
     <img src='imagenes/ochenta.png'  width='40%' class="Imagenpromo">
     </div> 
     
    
    </div>
    </div>
    

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.10.1/js/mdb.min.js"></script>
  </body>
</html>
