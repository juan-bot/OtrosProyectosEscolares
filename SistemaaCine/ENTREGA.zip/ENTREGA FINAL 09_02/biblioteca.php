<!--Hernandez Santos Marco Antonio.  Interfaz que muestra las promociones -->
<?php
// FUNCIÓN DE CONEXIÓN CON LA BASE DE DATOS MYSQL

function conectaDb()
{
    
$conexion = mysqli_connect('localhost', 'root','','basecinema');//hacemos la conexion con la base de datos
    if (!$conexion) {//verificamos que la conexion haya sido exitosa, si no es asi, debemos avisar al usuario
    echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
    echo "error de depuración: " . mysqli_connect_error() . PHP_EOL;
    exit;//abortamos el programa
} 
    return($conexion);
}

?>