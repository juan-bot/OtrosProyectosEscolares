<?php
	$conexion = mysqli_connect('localhost', 'root','', 'menu1');
	$v1=$_GET["q"];
	$d2=$_GET["d"];
	$aux=str_replace(",", "", $v1);
	var_dump($aux);
    $cons ="SELECT id_funcion FROM funciones WHERE horario=";
	$ejecutar=mysqli_query($conec,$cons);
	///////////
    $consulta = "UPDATE funciones
	SET sala = '$aux' WHERE id_pelicula=$d2";
	$ejecuta=mysqli_query($conexion,$consulta);

    print("chelas");
?>