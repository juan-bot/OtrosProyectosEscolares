function recorre(a,x,y){
  var cell=document.getElementById(x+""+y);
  if(a==0)
    cell.innerHTML='<img src="./imagenes/asiento1.jpg" width="100%" />';
  else if(a==1)
    cell.innerHTML='<img src="./imagenes/asiento2.jpg" width="100%" />';
}
