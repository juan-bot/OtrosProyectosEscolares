var ax=-1,ay=-1,v=0,b=0,j=0,cx=0,cy=0;
function selec(x,y){
	console.log("chelas");
  var cell=document.getElementById(x+""+y);
  v=0,b=0;
  if(seleccionado==0){
    for(j=0;j<10;j++){
      if(x==v && y==b){
        if(sala[j]==0){
          seleccionado=1;
          if(bandera==0 ){
            bandera=1;
            ax=x;
            ay=y;
            cx=x;
            cy=y;
            cell.innerHTML='<img src="./imagenes/asiento3.jpg" width="100%" />';
          }
        }
      }
      if((j+1)%12==0){
        v++;
        b=0;
      }
       else{
         b++;
       }
    }
  }
  else if(ax==x && ay==y && seleccionado==1){
    bandera=0;
    cell.innerHTML='<img src="./imagenes/asiento1.jpg" width="100%" />';
    ax=-1;
    ay=-1;
    seleccionado=0;
  }
}