<!--Velazquez zamora samuel-->
<!--Interfaz que muestra la pagina principal -->
<?php
require_once "biblioteca.php";//llamamos a la biblioteca que contiene la conexion
$conexion =conectaDB();//asignamos a una variable la conexion a la base de datos
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"><!-- compatiblilidad para todo tipo de dispositivos -->
    <link rel="stylesheet" href="css/estilo.css"><!-- importacion de carpeta de estilos -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.10.1/css/mdb.min.css" rel="stylesheet">
    <title>Inicio</title>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top" style="background-color: #232329;">
      <a class="navbar-brand" text-white href="#">CINEMA 4</a><!--  integracion del logo en el menu-->
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent" id="menu">
              <!-- div contenedor del header -->
        	<ul class="navbar nav ml-auto">
            <li class="nav-item ">
              <!--referencia a las opciones del menu para identificarlos al momento de que se requiera una accion con ellos  -->
              <a href='index.php'  class="nav-link text-light">INICIO</a>
            </li>
            <li class="nav-item ">
              <a href='Cartelera.php' class="nav-link text-light">CARTELERA</a>
            </li>
            <li class="nav-item ">
              <a href='Promociones.php' class="nav-link text-light">PROMOCIONES</a>
            </li>
            <li class="nav-item ">
              <a href="proximosEstrenos.php" class="nav-link text-light">PROXIMOS ESTRENOS</a>
            </li>
          </ul>
      </div>
    </nav>


    
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel"> <!--div contenedor de carousel   -->
      <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>

      </ol>
      <div class="carousel-inner"> <!-- clase que contiene la imagen que va a ser desplazada -->
        <div class="carousel-item active"> <!-- clase para activar el desplazamiento -->
            <?php 
                $result = mysqli_query($conexion, "SELECT link_imagen from cartelera where id_pelicula = 1");
                  if (!$result) {//verificamos que la conexion haya sido exitosa, si no es asi, debemos avisar al usuario
                    echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
                    echo "errno de depuración: " . mysqli_connect_errno() . PHP_EOL;
                    echo "error de depuración: " . mysqli_connect_error() . PHP_EOL;
                    exit;//abortamos el programa
                    }
                $fila = $result-> fetch_assoc();
                echo '<img class="d-block w-100" src="imagenes/second.jpg" alt="first sdfd">';
            ?> 
            <div class="carousel-caption d-none d-md-block text-left"> <!--desplazar la imagen a la izquierda  -->
            <h1 class="display-1 text-uppercase">Cine en familia</h1>
          </div>
        </div>
        <div class="carousel-item"> <!-- clase para activar el desplazamiento -->
            <?php 
                $result = mysqli_query($conexion, "SELECT link_imagen from cartelera where id_pelicula = 2");
                  if (is_null($result)) {//verificamos que la conexion haya sido exitosa, si no es asi, debemos avisar al usuario
                    echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
                    echo "errno de depuración: " . mysqli_connect_errno() . PHP_EOL;
                    echo "error de depuración: " . mysqli_connect_error() . PHP_EOL;
                    exit;//abortamos el programa
}
                $fila = $result-> fetch_assoc();
                echo '<img class="d-block w-100" src="imagenes/first.jpg" alt="second slide sdfd">';
            ?> 
          <div class="carousel-caption d-none d-md-block"><!--desplazar la imagen a la izquierda  -->
            <h1 class="display-1 text-uppercase">La mejor resolucion</h1>
          </div>
        </div>
      </div>
      <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
    <br>
    
    
    <section id="cartelera" class="container"><!-- contenedor de las imagenes -->
       <h3 style="display: flex;justify-content: center;align-items: center;"><strong>Peliculas mas vistas</strong></h3>
       <div class="row">
           <?php
        $sql="SELECT * FROM cartelera WHERE taquillero > 4 ";//se hace la consulta para phpmyadmin y la guardamos en una variable
		$result=mysqli_query($conexion,$sql);//hacemos la consulta con la ayuda de mysqli_queery
		//if(!$result){
		while($mostrar2=mysqli_fetch_array($result) ){//iniciamos el ciclo y le asignamos a una variable lo de la consulta
		?>
         <div class="col-lg-3 " align ="center"><!--este es para cada una de las imagenes -->
           	<?php //echo'<div class="col-lg-3"  align ="center" >';
			    echo ' <img  width="180px"  height="260px"  src="'.$mostrar2['link_imagen'].'"alt="first slide">';//imprimimos la imagen ,de la variable mostrar nosotros vamos a escojer el campo link_imagen
			    echo '<h5 align ="center"><strong>'.$mostrar2['nombre'].'<br><br></strong></h5>';
		    	//de igual forma nosotros vamos a mostrar de la variable mostrar solo nos interesa el nombre y eso lo imprimimos junto con codigo html
		    	//$variable=+1;?>
          
           
         </div>
		<?php
		}
		//ceramos el ciclo while 
		?>	
       </div>
     </section>
    
    
    
    
    
    
    
    
    
    <div class="container" class="social"><!--clase que contiene iframe de facebook -->

          <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FCinema-4-111958727040965%2F%3Fmodal%3Dadmin_todo_tour&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=false&hide_cover=false&show_facepile=false&appId" width="340" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
    </div>
    <br>
    <br>
    <h2 align="center"><strong>Generos Populares</strong></h2>
    <br>
    <section id="galeria" class="container"><!-- contenedor de las imagenes centrado-->
      <div class="row"><!--clase para indicar que sera por filas  -->
        <div class="col-lg-3 col-md-6 col-md-9 col-sm-12"><!--establece el tamaño de las imagenes con boostrap-->
          <h3 align="center">Comedia</h3>
          <img src='imagenes/comedia.jpg' ><!--se inserta la imagen  -->
        </div>
        <div class="col-lg-3 col-md-6 col-md-9 col-sm-12"><!--establece el tamaño de las imagenes con boostrap-->
          <h3 align="center">Familiar</h3>
          <img src='imagenes/familiar.jpg' >
        </div>
        <div class="col-lg-3 col-md-6 col-md-9 col-sm-12"><!--establece el tamaño de las imagenes con boostrap-->
          <h3 align="center">Ficcion</h3>
          <img src='imagenes/ficcion.jpg'>
        </div>
        <div class="col-lg-3 col-md-6 col-md-9 col-sm-12"><!--establece el tamaño de las imagenes con boostrap-->
          <h3 align="center">Accion</h3>
          <img src='imagenes/accion.jpg'>
        </div>
      </div>
    </section>
    
    
    <br>
    <div class="Propiedad2" >
      <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15258.396286816906!2d-96.7163238!3d17.
      043325!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x40b8b3b4368fce3!2sCin%C3%A9polis%20Oaxaca!5e0!3m2!1ses!2s
      mx!4v1578008591332!5m2!1ses!2smx" width="100%" height="100%" frameborder="0" style="border:0;" allowfullscreen="">
      </iframe>
   <div class="Propiedad">
    <div class="row">
        
    <div class="col-lg-4"> 
      <img src='imagenes/cinco.png'  class="Imagenpromo"> 
    </div>
    
    <div class="col-lg-4"> 
     <img src='imagenes/cuatro.png'  class="Imagenpromo"> 
    </div>
    
    <div class="col-lg-4"> 
     <img src='imagenes/dos.png'  class="Imagenpromo">
     </div> 
    
    <div class="col-lg-4"> 
     <img src='imagenes/tres.png'  class="Imagenpromo">
     </div>  
     
     <div class="col-lg-4"> 
     <img src='imagenes/treinta.png'  class="Imagenpromo">
     </div> 
     
     <div class="col-lg-4"> 
     <img src='imagenes/ochenta.png'  width='40%' class="Imagenpromo">
     </div> 
     
    
    </div>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <!-- JQuery -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.10.1/js/mdb.min.js"></script>
  </body>
</html>
